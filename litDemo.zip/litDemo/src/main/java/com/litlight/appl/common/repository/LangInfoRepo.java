package com.litlight.appl.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.litlight.appl.entity.LangInfoEty;

public interface LangInfoRepo extends JpaRepository<LangInfoEty, Integer>{

	
}
