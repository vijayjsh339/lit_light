package com.litlight.appl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.litlight.appl.entity.UserInfoEty;


@Repository
public interface UserDtlRepo extends JpaRepository<UserInfoEty, Long>{

}
