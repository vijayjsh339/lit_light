package com.litlight.appl.entity;

import java.io.Serializable;

public class AddressInfoEty implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
