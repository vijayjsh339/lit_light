package com.litlight.appl.service;

import com.litlight.appl.dto.UserDTO;

public interface UserRegSvc {
	
	public void createUsrProf(UserDTO userDTO);

}
