package com.litlight.appl.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.litlight.appl.common.repository.ConverterInfoRpeo;
import com.litlight.appl.common.repository.LangInfoRepo;
import com.litlight.appl.common.repository.UserRoleRepo;
import com.litlight.appl.entity.ConverterInfoEty;
import com.litlight.appl.entity.LangInfoEty;
import com.litlight.appl.entity.UserRoleInfoEty;

@Component
public class CommonDataUtil {

	private static Map<Integer, UserRoleInfoEty> userRoleMap = new HashMap<>();
	private static Map<Integer, LangInfoEty> langInfoMap = new HashMap<>();
	private static Map<Integer, ConverterInfoEty> cnvInfoMap = new HashMap<>();
	
	@Autowired
	private UserRoleRepo userRoleRepo;
	@Autowired
	private LangInfoRepo langInfoRepo;
	@Autowired
	private ConverterInfoRpeo converterInfoRpeo;
	

	List<UserRoleInfoEty> userRoleInfoLst ;
	List<LangInfoEty> langInfoLst;
	List<ConverterInfoEty> cnvInfoLst; 

	public static Map<Integer, UserRoleInfoEty> getUserRoleMap() {
		return userRoleMap;
	}

	public static void setUserRoleMap(Map<Integer, UserRoleInfoEty> userRoleMap) {
		CommonDataUtil.userRoleMap = userRoleMap;
	}

	public static Map<Integer, LangInfoEty> getLangInfoMap() {
		return langInfoMap;
	}

	public static void setLangInfoMap(Map<Integer, LangInfoEty> langInfoMap) {
		CommonDataUtil.langInfoMap = langInfoMap;
	}

	public static Map<Integer, ConverterInfoEty> getCnvInfoMap() {
		return cnvInfoMap;
	}

	public static void setCnvInfoMap(Map<Integer, ConverterInfoEty> cnvInfoMap) {
		CommonDataUtil.cnvInfoMap = cnvInfoMap;
	}

	public UserRoleRepo getUserRoleRepo() {
		return userRoleRepo;
	}

	public void setUserRoleRepo(UserRoleRepo userRoleRepo) {
		this.userRoleRepo = userRoleRepo;
	}

	public LangInfoRepo getLangInfoRepo() {
		return langInfoRepo;
	}

	public void setLangInfoRepo(LangInfoRepo langInfoRepo) {
		this.langInfoRepo = langInfoRepo;
	}

	public ConverterInfoRpeo getConverterInfoRpeo() {
		return converterInfoRpeo;
	}

	public void setConverterInfoRpeo(ConverterInfoRpeo converterInfoRpeo) {
		this.converterInfoRpeo = converterInfoRpeo;
	}
	
	
	public List<UserRoleInfoEty> getUserRoleInfoLst() {
		return userRoleInfoLst;
	}

	public void setUserRoleInfoLst(List<UserRoleInfoEty> userRoleInfoLst) {
		this.userRoleInfoLst = userRoleInfoLst;
	}

	public List<LangInfoEty> getLangInfoLst() {
		return langInfoLst;
	}

	public void setLangInfoLst(List<LangInfoEty> langInfoLst) {
		this.langInfoLst = langInfoLst;
	}

	public List<ConverterInfoEty> getCnvInfoLst() {
		return cnvInfoLst;
	}

	public void setCnvInfoLst(List<ConverterInfoEty> cnvInfoLst) {
		this.cnvInfoLst = cnvInfoLst;
	}

	
	@PostConstruct
	private void loadLookupMps(){
		
		System.out.println("LookUp Load MAPS START");
		Iterable<UserRoleInfoEty> userInfoItr  = userRoleRepo.findAll();
		
		userInfoItr.forEach(userRole->{
			userRoleMap.put(userRole.getRoleId(),userRole);
		});
		
		
		Iterable<LangInfoEty> langInfoItr = langInfoRepo.findAll();
		
		langInfoItr.forEach(langInfo -> {
			langInfoMap.put(langInfo.getLangId(), langInfo);
		});
		
		Iterable<ConverterInfoEty> cnvInfoItr = converterInfoRpeo.findAll();
		
		cnvInfoItr.forEach(cnvInfo -> {
			cnvInfoMap.put(cnvInfo.getCnvId(), cnvInfo);
		});
		
		System.out.println("END - LookUp Load MAPS");
	}


}
