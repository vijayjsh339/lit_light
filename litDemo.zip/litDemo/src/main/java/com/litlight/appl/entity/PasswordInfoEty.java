package com.litlight.appl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.catalina.User;

import com.litlight.appl.common.entity.BaseEntity;

@Entity
@Table(name = "password")
public class PasswordInfoEty {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pwd_id")
	private int pwdId;

	@Column(name = "password")
	private String password;

	@Column(name = "user_id")
	private int userId;
	
	@OneToOne(optional=false)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id",insertable=false, updatable = false) 
	private UserInfoEty userInfoEty;

	public int getPwdId() {
		return pwdId;
	}

	public void setPwdId(int pwdId) {
		this.pwdId = pwdId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId; 
	}

}
