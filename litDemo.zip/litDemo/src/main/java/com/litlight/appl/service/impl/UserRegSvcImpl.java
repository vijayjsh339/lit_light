package com.litlight.appl.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.litlight.appl.dto.UserDTO;
import com.litlight.appl.entity.PasswordInfoEty;
import com.litlight.appl.entity.UserInfoEty;
import com.litlight.appl.repository.ActorRepo;
import com.litlight.appl.repository.UserDtlRepo;
import com.litlight.appl.service.UserRegSvc;

@Service
public class UserRegSvcImpl implements UserRegSvc {

	@Autowired
	private UserDtlRepo userDtlRepo;
	
	@Autowired
	private ActorRepo actorRepo;

	public void createUsrProf(UserDTO userDTO) {

	/*	ActorEty actorEty = new ActorEty();
		actorEty.setFirstName("jar");
		actorEty.setLastName("hga");
		actorEty.setLastUpdate(new Date());
		
		ActorEty ety =  actorRepo.save(actorEty);
		System.out.println(ety);*/

		UserInfoEty userInfoEty = userDtlRepo.save(convertToEntity(userDTO));

		System.out.println("USER 1122 - " + userInfoEty);
	}

	private UserInfoEty convertToEntity(UserDTO userDTO) {
		UserInfoEty userInfo = new UserInfoEty();
		userInfo.setUserNm(userDTO.getUserNm());
		userInfo.setUserRole(userDTO.getUserRole());
		userInfo.setEmailId(userDTO.getEmailId());
		userInfo.setMobNum(userDTO.getMobNum());
		userInfo.setKnownLang(userDTO.getKnownLang());
		PasswordInfoEty passwordInfoEty = new PasswordInfoEty();
		passwordInfoEty.setPassword("c10");
		passwordInfoEty.setUserId(userInfo.getUserId());
		userInfo.setPasswordInfoEty(passwordInfoEty);
		return userInfo;
	}

}
