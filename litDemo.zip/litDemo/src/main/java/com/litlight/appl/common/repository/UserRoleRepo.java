package com.litlight.appl.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.litlight.appl.entity.UserRoleInfoEty;

public interface UserRoleRepo extends JpaRepository<UserRoleInfoEty, Integer>{

		
}
