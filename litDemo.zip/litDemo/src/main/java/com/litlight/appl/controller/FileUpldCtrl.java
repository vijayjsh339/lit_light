package com.litlight.appl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.litlight.appl.dto.FileUpldVo;
import com.litlight.appl.exception.ResourceNotFoundException;
import com.litlight.appl.repository.FileUpldRepository;
import com.litlight.appl.repository.UserDtlRepo;


@RestController
@RequestMapping("/api")
public class FileUpldCtrl {

	@Autowired
	FileUpldRepository fileUpldRepository;
	
	@Autowired
	UserDtlRepo usr;
	
	@GetMapping("/allFiles")
	public List<FileUpldVo> getAllFiles(){
		return fileUpldRepository.findAll();
	}
	
	@PostMapping("/upldFile")
	public FileUpldVo upldDoc(@RequestBody FileUpldVo fileUpldVo){
		return fileUpldRepository.save(fileUpldVo);
	}
	
	@GetMapping("/files/{id}")
	public FileUpldVo getReqFile(@PathVariable(value="id") Long reqDocId){
		
		return fileUpldRepository.findById(reqDocId).orElseThrow(()-> new ResourceNotFoundException("File", "id", reqDocId));
		
	}
	

}
