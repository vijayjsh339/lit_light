package com.litlight.appl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "converter_info")
public class ConverterInfoEty {

	
	@Id
	@GeneratedValue
	@Column(name = "cnv_id")
	private int cnvId;
	
	@Column(name = "cnv_cd")
	private String cnvCd;
	
	@Column(name = "cnv_desc")
	private String cnvDesc;

	public int getCnvId() {
		return cnvId;
	}

	public void setCnvId(int cnvId) {
		this.cnvId = cnvId;
	}

	public String getCnvCd() {
		return cnvCd;
	}

	public void setCnvCd(String cnvCd) {
		this.cnvCd = cnvCd;
	}

	public String getCnvDesc() {
		return cnvDesc;
	}

	public void setCnvDesc(String cnvDesc) {
		this.cnvDesc = cnvDesc;
	}

}
