package com.litlight.appl.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_role_info")
public class UserRoleInfoEty implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2151742463586814909L;

	@Id
	@GeneratedValue
	@Column(name = "role_id")
	private int roleId;
	
	@Column(name = "role_nm")
	private String roleNm;
	
	@Column(name = "role_desc")
	private String roleDesc;

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRoleNm() {
		return roleNm;
	}

	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

}
