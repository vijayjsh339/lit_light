package com.litlight.appl.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7044650511180869564L;

	private String resourceName;
	private String fieldName;
	private Object fieldVal;

	public ResourceNotFoundException(String resourceName, String fieldName, Object fieldVal) {
		super(String.format("%s not found with %s : '%s'", resourceName, fieldName, fieldVal));
		this.resourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldVal = fieldVal;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public Object getFieldVal() {
		return fieldVal;
	}

	public void setFieldVal(Object fieldVal) {
		this.fieldVal = fieldVal;
	}

}
