package com.litlight.appl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "lang_info")
public class LangInfoEty {
	
	@Id
	@GeneratedValue
	@Column(name = "lang_id")
	private int langId;
	
	@Column(name = "lang_cd")
	private String langCd;
	
	@Column(name = "lang_desc")
	private String langDesc;

	public int getLangId() {
		return langId;
	}

	public void setLangId(int langId) {
		this.langId = langId;
	}

	public String getLangCd() {
		return langCd;
	}

	public void setLangCd(String langCd) {
		this.langCd = langCd;
	}

	public String getLangDesc() {
		return langDesc;
	}

	public void setLangDesc(String langDesc) {
		this.langDesc = langDesc;
	}

}
