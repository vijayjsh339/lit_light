package com.litlight.appl.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.litlight.appl.entity.ConverterInfoEty;

public interface ConverterInfoRpeo extends JpaRepository<ConverterInfoEty, Integer> {

}
