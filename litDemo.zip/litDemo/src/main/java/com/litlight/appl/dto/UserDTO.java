package com.litlight.appl.dto;

import com.litlight.appl.common.dto.BaseDto;
import com.litlight.appl.entity.AddressInfoEty;

public class UserDTO extends BaseDto {

	private int userId;
	private String userNm;
	private String emailId;
	private String mobNum;;
	private String userRole;
	private String knownLang;
	private AddressInfoEty address;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobNum() {
		return mobNum;
	}

	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getKnownLang() {
		return knownLang;
	}

	public void setKnownLang(String knownLang) {
		this.knownLang = knownLang;
	}

	public AddressInfoEty getAddress() {
		return address;
	}

	public void setAddress(AddressInfoEty address) {
		this.address = address;
	}

}
