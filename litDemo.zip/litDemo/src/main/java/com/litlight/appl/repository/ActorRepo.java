package com.litlight.appl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.litlight.appl.entity.ActorEty;

public interface ActorRepo extends JpaRepository<ActorEty,Long>{
	

}
