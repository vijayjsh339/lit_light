package com.litlight.appl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "req_doc_audio_dtl")
public class UpldDocAudFileInfoEty {

	@Column(name = "req_resp_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int reqRespId;
	
	@Column(name = "req_doc_id")
	private int reqDocId;
	
	
	@Column(name = "vltr_id")
	private int vltrId;
	
	
	@Column(name = "vltr_role")
	private String vltrRole;
	
	
	@Column(name = "comments")
	private String comments;
	
	
	@Column(name = "aud_file_path")
	private String audFilePath; 	
	
	@Column(name = "aud_upld_dt")
	private String audUpldDt;

	public int getReqRespId() {
		return reqRespId;
	}

	public void setReqRespId(int reqRespId) {
		this.reqRespId = reqRespId;
	}

	public int getReqDocId() {
		return reqDocId;
	}

	public void setReqDocId(int reqDocId) {
		this.reqDocId = reqDocId;
	}

	public int getVltrId() {
		return vltrId;
	}

	public void setVltrId(int vltrId) {
		this.vltrId = vltrId;
	}

	public String getVltrRole() {
		return vltrRole;
	}

	public void setVltrRole(String vltrRole) {
		this.vltrRole = vltrRole;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getAudFilePath() {
		return audFilePath;
	}

	public void setAudFilePath(String audFilePath) {
		this.audFilePath = audFilePath;
	}

	public String getAudUpldDt() {
		return audUpldDt;
	}

	public void setAudUpldDt(String audUpldDt) {
		this.audUpldDt = audUpldDt;
	}
	
	
}
