package com.litlight.appl.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "user_upld_doc_info")
public class FileUpldVo implements Serializable {

	/**
	 * 											

	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "req_doc_id")
	private Long reqDocId;
	
	@Column(name = "doc_type")
	private String docType;
	
	@Column(name = "doc_nm")
	private String docNm;
	
	@Column(name = "doc_upld_by")
	private String docUpldBy;
	
	@Column(name = "user_role")
	private String userRole;
	
	@Column(name = "doc_upld_dt")
	@Temporal(TemporalType.TIMESTAMP)
	private Date docUpldDt;
	
	@Column(name = "crnt_doc_lang")
	@NotBlank
	private String crntDocLang;
	
	@Column(name = "req_aud_lang")
	@NotBlank
	private String reqAudLang;
	
	
	@Column(name = "upld_doc_path")
	private String upldDocPath;
	
	@Column(name = "comments")
	private String comments;
	
	@Column(name = "doc_cnv_stt")
	private String docCnvStt;
	
	@Column(name = "req_acpt_stt")
	private String reqAcptStt;

	public Long getReqDocId() {
		return reqDocId;
	}

	public void setReqDocId(Long reqDocId) {
		this.reqDocId = reqDocId;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocUpldBy() {
		return docUpldBy;
	}

	public void setDocUpldBy(String docUpldBy) {
		this.docUpldBy = docUpldBy;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Date getDocUpldDt() {
		return docUpldDt;
	}

	public void setDocUpldDt(Date docUpldDt) {
		this.docUpldDt = docUpldDt;
	}

	public String getCrntDocLang() {
		return crntDocLang;
	}

	public void setCrntDocLang(String crntDocLang) {
		this.crntDocLang = crntDocLang;
	}

	public String getReqAudLang() {
		return reqAudLang;
	}

	public void setReqAudLang(String reqAudLang) {
		this.reqAudLang = reqAudLang;
	}

	public String getUpldDocPath() {
		return upldDocPath;
	}

	public void setUpldDocPath(String upldDocPath) {
		this.upldDocPath = upldDocPath;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDocCnvStt() {
		return docCnvStt;
	}

	public void setDocCnvStt(String docCnvStt) {
		this.docCnvStt = docCnvStt;
	}

	public String getReqAcptStt() {
		return reqAcptStt;
	}

	public void setReqAcptStt(String reqAcptStt) {
		this.reqAcptStt = reqAcptStt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDocNm() {
		return docNm;
	}

	public void setDocNm(String docNm) {
		this.docNm = docNm;
	}

	
}
