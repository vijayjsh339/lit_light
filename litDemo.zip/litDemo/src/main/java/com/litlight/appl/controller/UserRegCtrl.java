package com.litlight.appl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.litlight.appl.dto.UserDTO;
import com.litlight.appl.service.UserRegSvc;

@RestController
@RequestMapping("/user")
public class UserRegCtrl {
	
	@Autowired
	private UserRegSvc userRegSvc;
	
	@PostMapping("/register")
	public void createUsrProf(@RequestBody UserDTO userDTO){
		
		userRegSvc.createUsrProf(userDTO);
		
	}
	
}
