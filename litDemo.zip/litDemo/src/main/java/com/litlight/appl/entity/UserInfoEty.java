package com.litlight.appl.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.litlight.appl.common.entity.BaseEntity;

@Entity
@Table(name = "reg_user_info")
@DynamicUpdate
public class UserInfoEty extends BaseEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private int userId;

	@Column(name = "user_nm")
	private String userNm;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "mob_num")
	private String mobNum;;
	@Column(name = "user_role")
	private String userRole;

	@Column(name = "known_lang")
	private String knownLang;

	/*@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private String createdDt;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_dt")
	private String lastUpdatedDt;*/

	private AddressInfoEty address;
	
	
	/*@OneToOne(optional=false,cascade=CascadeType.ALL, 
		  mappedBy="userInfoEty",targetEntity=PasswordInfoEty.class)*/
	@OneToOne(mappedBy = "userInfoEty", cascade = CascadeType.ALL)
	private PasswordInfoEty password;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobNum() {
		return mobNum;
	}

	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getKnownLang() {
		return knownLang;
	}

	public void setKnownLang(String knownLang) {
		this.knownLang = knownLang;
	}

	/*public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(String lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}*/

	public AddressInfoEty getAddress() {
		return address;
	}

	public void setAddress(AddressInfoEty address) {
		this.address = address;
	}

	public PasswordInfoEty getPasswordInfoEty() {
		return password;
	}

	public void setPasswordInfoEty(PasswordInfoEty password) {
		this.password = password;
	}

}
